package institut;

public class Institut {

    public static void main(String[] args) {

        // Creem un CicleArray amb capacitat per a 5 mòduls
        CicleArray cicle = new CicleArray("DAM", 25, 5);

        System.out.println("Estat inicial CicleArray:");
        System.out.println(cicle);

        // Creem alguns mòduls
        Modul modul1 = new Modul("Programació", 6);
        Modul modul2 = new Modul("Bases de Dades", 5);
        Modul modul3 = new Modul("Sistemes", 4);

        // Afegim els mòduls al cicle
        boolean afegit1 = cicle.afegirModul(modul1);
        boolean afegit2 = cicle.afegirModul(modul2);
        boolean afegit3 = cicle.afegirModul(modul3);

        System.out.println("\nDesprés d'afegir mòduls:");
        System.out.println(cicle);

        System.out.println("\nResultats afegirModul:");
        System.out.println(modul1.getNom() + " afegit? " + afegit1);
        System.out.println(modul2.getNom() + " afegit? " + afegit2);
        System.out.println(modul3.getNom() + " afegit? " + afegit3);

        // Provem tornaModul
        System.out.println("\nBusquem un mòdul pel nom:");
        Modul trobat = cicle.tornaModul("Bases de Dades");
        if (trobat != null) {
            System.out.println("Mòdul trobat: " + trobat);
        } else {
            System.out.println("Mòdul no trobat.");
        }

        Modul noTrobat = cicle.tornaModul("Filosofia");
        if (noTrobat != null) {
            System.out.println("Mòdul trobat: " + noTrobat);
        } else {
            System.out.println("Mòdul 'Filosofia' no trobat.");
        }
    }
}
