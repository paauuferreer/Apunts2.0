package institut;

/**
 * 1. Crea una classe que representi un Modul(assignatura) d'uns estudis.

*Defineix com a atributs el nom i les horesSetmanals.

*Genera tots els getters i setters. Ho pots fer amb les utilitats que proporciona l'IDE.

*Crea un constructor amb paràmetres per inicialitzar tots els atributs.

*Amb l'ajuda de l'IDE genera el mètode toString
 
 * @author bypau
 */

    
public class Modul {
    
    //Atributs
    private String nom;
    private int horesSetmanals;
    
    //Constructor amb paràmetres
    public Modul(String nom, int horesSetmanals){
        this.nom = nom;
        this.horesSetmanals = horesSetmanals;
    }
    
    //Getter i Setter Nom
    public String getNom(){
        return nom;
    }
    
    public void setNom(String nom){
        this.nom = nom;
    }
    
    //Getter i Setter horesSetmanals
    public int getHoresSetmanals(){
        return horesSetmanals;
    }
    
    public void setHoresSetmanals(int horesSetmanals){
        this.horesSetmanals = horesSetmanals;
    }
    
    //Mètode toString
    @Override
    public String toString() {
    return "Modul{" +
            "nom='" + nom + '\'' +
            ", horesSetmanals=" + horesSetmanals +
            '}';
}
    
    
}

