
package trastos;

/**
 *
 * @author bypau
 */
public class ProvaTrasto {
    
    
    public static void main(String[] args) {

        // Accés a l'atribut de classe SENSE crear objectes
        Trasto.setContador(10);
        System.out.println("Contador inicial: " + Trasto.getContador());

        // Creem tres objectes
        Trasto t1 = new Trasto("Cadira");
        Trasto t2 = new Trasto("Taula");
        Trasto t3 = new Trasto("Lampara");

        // Modifiquem l'atribut de classe des d'un objecte
        t1.setContador(25);

        // Comprovem des d'un altre objecte
        System.out.println("Contador vist des de t2: " + t2.getContador());

        // Mostrem tots els objectes
        System.out.println(t1);
        System.out.println(t2);
        System.out.println(t3);
    }
    
}
