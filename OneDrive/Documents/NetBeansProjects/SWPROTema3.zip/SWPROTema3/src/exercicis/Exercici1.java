/** Exercici 1

*Crea un fitxer amb main i un mètode anomenat simpatic que rebi com a paràmetre una cadena de caràcters amb un nom i saludi aquesta persona. Crida'l des del main.

* @author Pau Ferrer

*/

  void main() {
        simpatic("Pau");
    }

  void simpatic(String nom) {
        IO.println("Hola, " + nom + "! Encantat de saludar-te.");
    }


