/* Exercici 1

*Calcula la longitud d'una circumferència a partir del radi.

* @author Pau Ferrer

*/
void main() {
    
    final double pi = 3.14159; 
    double radi=55;
    double longitud = pi * (radi * 2);
    
        IO.println (longitud);

   
    
}
