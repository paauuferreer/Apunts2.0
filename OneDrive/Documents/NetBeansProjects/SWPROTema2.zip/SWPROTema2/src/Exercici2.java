/* Exercici 2

*Donada una velocitat v expressada en km/h passar-la a m/s (v*1000/3600). Fes el càlcul amb decimals.

* @author Pau Ferrer

*/
void main() {

double velocitat = 120;
double velocitat2 = (velocitat * 1000) / 3600;

      IO.println(velocitat2);





}
