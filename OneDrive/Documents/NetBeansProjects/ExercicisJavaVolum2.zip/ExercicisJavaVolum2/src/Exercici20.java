/* Exercici 20

*Recupera un nombre del teclat i mostra la taula de multiplicar d'aquest nombre.

* @author Pau Ferrer
*/

void main (){

    int valor = 10;
    int index;

     for (index = 1; index <= 10; index++) {
             IO.println(valor + " x " + index + " = " + (valor * index));
        }
    }




