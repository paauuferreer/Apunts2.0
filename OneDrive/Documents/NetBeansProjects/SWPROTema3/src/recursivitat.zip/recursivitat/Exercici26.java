void main() {
 System.out.print("Hola!");
 }
 void saluda(String nom) {
 System.out.print("Hola " + nom + " !");
 }
 void saluda(String nom1, String nom2) {
 System.out.print("Hola " + nom1 + " i " + nom2 + " !");
 }
 void saluda(String nom, int dies) {
 System.out.print("Hola " + nom + " ! Feia " + dies + " que no et veia!");
 }