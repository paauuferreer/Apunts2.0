import utilitats.UtilitatsConsola;

void main(){
    int[] enters = {1, 2, 3};
boolean[] booleans = {true, false, true};
double[] decimals = {3.14, 2.71};
String[] paraules = {"Hola", "Adeu"};

UtilitatsConsola.mostrarArray(enters);
UtilitatsConsola.mostrarArray(booleans);
UtilitatsConsola.mostrarArray(decimals);
UtilitatsConsola.mostrarArray(paraules);

}